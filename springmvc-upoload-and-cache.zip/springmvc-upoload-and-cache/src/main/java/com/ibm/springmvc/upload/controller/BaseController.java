package com.ibm.springmvc.upload.controller;

public class BaseController {
    
    //Save the uploaded file to this folder
    public static String UPLOADED_FOLDER = "D://upload//";
}
