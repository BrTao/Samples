package com.ibm.springmvc.cache;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCachePrefix;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Slf4j
@Configuration
@PropertySource("classpath:/redis.properties")
public class RedisConfiguration {
    private @Value("${redis.host}") String redisHost;
    private @Value("${redis.port}") int redisPort;
    
    @Value("${spring.cache.cachePrefix}")
    private String cachePrefix;
    
    @Value("${spring.cache.defaultExpiration}")
    private Long defaultExpiration;
    
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }
    
    @Bean
    JedisConnectionFactory jedisConnectionFactory() {
        JedisConnectionFactory factory = new JedisConnectionFactory();
        factory.setHostName(redisHost);
        factory.setPort(redisPort);
        factory.setUsePool(true);
        return factory;
    }
    
    /**
     * 设置RedisCacheManager
     * 使用cache注解管理redis缓存
     *
     * @return
     */
    @Bean
    public RedisCacheManager cacheManager() {
        log.info(this.cachePrefix);
        log.info(this.defaultExpiration.toString());
        
        RedisCacheManager redisCacheManager = new RedisCacheManager(redisTemplate());
        redisCacheManager.setUsePrefix(true);
        RedisCachePrefix cachePrefix = new RedisPrefix(this.cachePrefix);
        redisCacheManager.setCachePrefix(cachePrefix);
        // 整体缓存过期时间
        redisCacheManager.setDefaultExpiration(this.defaultExpiration);
        return redisCacheManager;
    }
    
    @Bean
    RedisTemplate<Object, Object > redisTemplate() {
        final RedisTemplate< Object, Object > template =  new RedisTemplate< Object, Object >();
        template.setConnectionFactory( jedisConnectionFactory() );
        template.setKeySerializer( new StringRedisSerializer() );
        template.setHashValueSerializer( new GenericToStringSerializer< Object >( Object.class ) );
        // template.setValueSerializer( new GenericToStringSerializer< Object >( Object.class ) );
        // 如果使用GenericToStringSerializer, 序列化的时候报错
        // No converter found capable of converting from type [com.ibm.springmvc.cache.model.Book] to type [java.lang.String]
    
        Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    
        jackson2JsonRedisSerializer.setObjectMapper(objectMapper);
        //set value serializer
        template.setDefaultSerializer(jackson2JsonRedisSerializer);
        return template;
    }
}
