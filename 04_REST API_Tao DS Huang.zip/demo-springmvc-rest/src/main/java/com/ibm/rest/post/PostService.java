package com.ibm.rest.post;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.rest.entity.Product;


@Component
public class PostService {

	private Product product;
	
	public void addProduct(Product product) {
		this.product=product;
        ObjectMapper om=new ObjectMapper();
        try {
            String jsonStr = om.writeValueAsString(product);

            CloseableHttpResponse httpResponse = null;
            CloseableHttpClient httpClient = HttpClientBuilder.create().setRetryHandler(new DefaultHttpRequestRetryHandler()).build();

            StringEntity stringEntity = new StringEntity(jsonStr,"UTF-8");
            stringEntity.setContentType("application/json");
            HttpUriRequest httpUriRequest = RequestBuilder.post("http://localhost:8080/product/add").setEntity(stringEntity).build();
            httpResponse = httpClient.execute(httpUriRequest);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            System.out.println("服务器响应：" + statusCode);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}
	
	public void updProduct(Product product) {
		this.product=product;
        ObjectMapper om=new ObjectMapper();
        try {
            String jsonStr = om.writeValueAsString(product);

            CloseableHttpResponse httpResponse = null;
            CloseableHttpClient httpClient = HttpClientBuilder.create().setRetryHandler(new DefaultHttpRequestRetryHandler()).build();

            StringEntity stringEntity = new StringEntity(jsonStr,"UTF-8");
            stringEntity.setContentType("application/json");
            HttpUriRequest httpUriRequest = RequestBuilder.post("http://localhost:8080/product/update").setEntity(stringEntity).build();
            httpResponse = httpClient.execute(httpUriRequest);
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            System.out.println("服务器响应：" + statusCode);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}
	
}
