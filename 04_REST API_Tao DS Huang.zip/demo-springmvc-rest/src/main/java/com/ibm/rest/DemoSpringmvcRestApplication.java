package com.ibm.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ibm.rest.entity.Product;
import com.ibm.rest.post.PostService;

@SpringBootApplication
public class DemoSpringmvcRestApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringmvcRestApplication.class, args);
		
		Product product = new Product();
		product.setId(1);
		product.setName("name1");
		product.setPrice(100);
		product.setDescription("description 1");
		
		PostService postService = new PostService();
		
		postService.addProduct(product);
		
		product.setName("updated name");
		postService.updProduct(product);
	}
}
