package com.ibm.rest.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.rest.entity.Product;



@RestController
public class ProductController {
	@PostMapping("/product/add")
	public void addProduct(@RequestBody Product product) {
		System.out.println("product added");
		System.out.println(product.toString());
		
	}
	
	@GetMapping(value="/product/del/{id}")
	public String delProduct(@PathVariable int id) {
		
		return "product with id " + id + " removed";
	}
	
	@PostMapping(value="/product/update")
	public void updateProduct(@RequestBody Product product) {
		System.out.println("updated product is " + product.toString());
	}
	
	@GetMapping(value="/product/list")
	public List<Product> listProduct() {
		List productList = new ArrayList<Product>();
		for(int i=1;i<5;i++) {
			Product product = new Product();
			product.setId(i);
			product.setName("name" + i);
			product.setPrice(i*1000);
			product.setDescription("description" + i);
			productList.add(product);
		}
		return productList;
	}
}
