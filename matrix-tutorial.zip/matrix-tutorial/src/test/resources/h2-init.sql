create table if not exists client (
  id            int not null primary key auto_increment
, name          varchar(100)
, password      varchar(100)
, status        varchar(100)
);

create table if not exists client_identity (
  id            int not null primary key auto_increment
, client_id     int not null
, identity_type varchar(20)
, surname       varchar(100)
, given_name    varchar(100)
);

/**
 * Would be called multiple times when initializing
 */
--insert into client (name) values ('MJ1');
--insert into client_identity(client_id, identity_type, surname, given_name) values (1, 'NATID', 'Michael-1', 'Jordan-1');
