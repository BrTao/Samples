package com.matrix.tutorial.test;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.matrix.tutorial.biz.entity.Client;
import com.matrix.tutorial.persistence.mybatis.service.MybatisClientService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MybatisTester {
	@Resource
	MybatisClientService mybatisService;
	
	@Test
	public void testAddClient() {
		Assert.assertNotNull(mybatisService);
		Client client = mybatisService.getById(1);
		Assert.assertNull(client);
		client = new Client().setName("Tom");
		mybatisService.addClient(client);
		client = mybatisService.getById(1);
		Assert.assertNotNull(client);
	}
}
