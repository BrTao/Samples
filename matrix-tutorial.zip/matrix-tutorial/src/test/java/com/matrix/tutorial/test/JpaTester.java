package com.matrix.tutorial.test;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.matrix.tutorial.biz.entity.Client;
import com.matrix.tutorial.biz.entity.ClientIdentity;
import com.matrix.tutorial.persistence.jpa.service.JpaClientService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JpaTester {
	@Resource
	JpaClientService jpaService;
	
	@Test
	public void testAddClient() {
		Assert.assertNotNull(jpaService);
		
		Client client = new Client().setName("Tom");
		client.getIdentities().add(new ClientIdentity().setSurname("MJ"));
		jpaService.addClient(client);
		
		client = jpaService.getById(1L);
		System.out.println("client="+client);
		Assert.assertNotNull(client);
	}
}
