package com.matrix.tutorial.persistence.mybatis.mapper;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;

import com.matrix.tutorial.biz.entity.ClientIdentity;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Tom
 * @since 2018-06-27
 */
//public interface ClientIdentityMapper extends BaseMapper<ClientContact> {
public interface ClientIdentityMapper {
	@Options(useGeneratedKeys = true, keyProperty = "id") //回写自增的主键ID
	@Insert("insert into client_identity (client_id, surname, given_name) values(#{clientId}, #{surname}, #{givenName})")
	public Integer addClientIdentity(ClientIdentity clientIdentity);
	
//	@Select("select * from client_contact where client_id=#{clientId}")
	List<ClientIdentity> listByClientId(@Param("clientId") Serializable clientId);
}
