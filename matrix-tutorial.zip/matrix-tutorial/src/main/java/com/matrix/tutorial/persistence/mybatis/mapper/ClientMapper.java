package com.matrix.tutorial.persistence.mybatis.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;

import com.matrix.tutorial.biz.entity.Client;


public interface ClientMapper {
	@Options(useGeneratedKeys = true, keyProperty = "id") //回写自增的主键ID
	@Insert("insert into client (name) values(#{name})")
	public Integer addClient(Client client);
	
	//@Select("select * from client where id=#{0}")
	public Client getById(Integer id);
}
