package com.matrix.tutorial.persistence.jpa.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.matrix.tutorial.biz.entity.Client;

@Service
@Transactional
public class JpaClientService {
	@PersistenceContext
	EntityManager entityManager;
	
	public Client addClient(Client client) {
		entityManager.persist(client);
		
		return client;
	}
	
	public Client getById(Long clientId) {
		return entityManager.find(Client.class, clientId);
	}
	
	public List<Client> all() {
		Query query = entityManager.createQuery("from Client");
		return query.getResultList();
	}
}
