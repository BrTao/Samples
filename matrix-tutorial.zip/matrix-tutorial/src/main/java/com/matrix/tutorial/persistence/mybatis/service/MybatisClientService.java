package com.matrix.tutorial.persistence.mybatis.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.matrix.tutorial.biz.entity.Client;
import com.matrix.tutorial.biz.entity.ClientIdentity;
import com.matrix.tutorial.persistence.mybatis.mapper.ClientIdentityMapper;
import com.matrix.tutorial.persistence.mybatis.mapper.ClientMapper;

@Service
public class MybatisClientService {
	@Resource
	ClientMapper clientMapper;
	
	@Resource
	ClientIdentityMapper clientIdentityMapper;
	
	public Integer addClient(Client client) {
		Integer result = clientMapper.addClient(client);
		for(ClientIdentity clientIdentity : client.getIdentities()) {
			clientIdentity.setClientId(client.getId());
			clientIdentityMapper.addClientIdentity(clientIdentity);
		}
		return result; 
	}
	
	public Client getById(Integer clientId) {
		return clientMapper.getById(clientId);
	}
}
