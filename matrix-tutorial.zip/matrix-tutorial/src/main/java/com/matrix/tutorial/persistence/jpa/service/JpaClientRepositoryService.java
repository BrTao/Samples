package com.matrix.tutorial.persistence.jpa.service;

import org.springframework.data.repository.CrudRepository;

import com.matrix.tutorial.biz.entity.Client;

public interface JpaClientRepositoryService extends CrudRepository<Client, Long>  {

}
