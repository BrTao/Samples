package com.matrix.tutorial;

import java.util.List;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrix.tutorial.biz.entity.Client;
import com.matrix.tutorial.biz.entity.ClientIdentity;
import com.matrix.tutorial.persistence.jpa.service.JpaClientRepositoryService;
import com.matrix.tutorial.persistence.jpa.service.JpaClientService;
import com.matrix.tutorial.persistence.mybatis.service.MybatisClientService;
import com.matrix.tutorial.persistence.mybatis.service.MybatisSqlService;

/**
 * References: - h2 https://blog.csdn.net/mn960mn/article/details/54644908
 * 
 * @author zenggb
 *
 */
@SpringBootApplication
public class MatrixTutorialApp {
	public static ApplicationContext ctx = null;

	public static void main(String[] args) throws Throwable {
		boolean isWebApp = true;
		// isWebApp = false;

		ctx = new SpringApplicationBuilder(MatrixTutorialApp.class).web(isWebApp).run(args);

//		showContext();

		jpa();
//		repository();

//		mybatis();

//		sql();
	}

	private static void showContext() throws Throwable {
		String[] beanNames = ctx.getBeanDefinitionNames();

		for (String beanName : beanNames) {
			System.out.println("beanName = " + beanName);
		}
	}

	private static void jpa() throws Throwable {
		System.out.println("JPA...");

		Client client = null;
		JpaClientService jpaService = ctx.getBean(JpaClientService.class);

		client = (new Client()).setName("LBJ");
		client.getIdentities().add(new ClientIdentity().setSurname("James").setGivenName("Lebron"));
		;
		jpaService.addClient(client);
//		System.out.println("client="+client);
		System.out.println("all.size=" + jpaService.all().size());
		System.out.println("all=" + jpaService.all());

		client = jpaService.getById(1L);
		System.out.println("client=" + client);
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(client);
		System.out.println("json=" + json);

	}

	private static void repository() throws Throwable {
		System.out.println("JPA Repository Service ...");

		Client client = null;
		JpaClientRepositoryService jpaClientRepositoryService = ctx.getBean(JpaClientRepositoryService.class);
		System.out.println("jpaClientRepositoryService=" + jpaClientRepositoryService);
		client = jpaClientRepositoryService.save(new Client().setName("Jack"));
		System.out.println("client@repository=" + client);

		client = jpaClientRepositoryService.findOne(1L);
		System.out.println("client@repository=" + client);
	}

	private static void mybatis() throws Throwable {
		System.out.println("Mybatis...");
		Client client = null;
		MybatisClientService mybatisService = ctx.getBean(MybatisClientService.class);

		client = new Client().setName("JH");
		client.getIdentities().add(new ClientIdentity().setSurname("Hardon").setGivenName("James"));
		Integer newId = mybatisService.addClient(client);
		System.out.println("newClient=" + client);

		client = mybatisService.getById(1);
		System.out.println("client=" + client);
//		
//		client = mybatisService.getById(2);
//		System.out.println("client[2]="+client);
	}

	private static void sql() throws Throwable {
		/*
		 * Prepare Data
		 */
		JpaClientService jpaService = ctx.getBean(JpaClientService.class);
		Client client = (new Client()).setName("JH");
		client.getIdentities().add(new ClientIdentity().setSurname("Hardon").setGivenName("James"));
		;
		jpaService.addClient(client);
		client = (new Client()).setName("LBJ");
		client.getIdentities().add(new ClientIdentity().setSurname("James").setGivenName("Lebron"));
		;
		jpaService.addClient(client);

		/*
		 * SQL Query
		 */
		MybatisSqlService mybatisSqlService = ctx.getBean(MybatisSqlService.class);
		List list = mybatisSqlService.query();

		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(list);
		System.out.println("json=" + json);
	}
}
