package com.demo.db;

import java.sql.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;

import com.demo.db.entity.OrderItem;
import com.demo.db.entity.Product;
import com.demo.db.entity.Torder;
import com.demo.db.jpa.service.JpaTorderService;
import com.demo.db.jpa.service.JpaTordertRepositoryService;
import com.demo.db.mybatis.service.MybatisSqlService;
import com.demo.db.mybatis.service.MybatisTorderService;
import com.fasterxml.jackson.databind.ObjectMapper;



/**
 * Hello world!
 *
 */
@SpringBootApplication
public class App 
{
	public static ApplicationContext ctx = null;
	
    public static void main (String[] args) throws Throwable
    {
    	
System.out.println("test1");
    	ctx = new SpringApplicationBuilder(App.class).web(true).run(args);
    	System.out.println("test2");
    	showContext();
    	//jpa();
    	//repository();
    	//mybatis();
    	sql();
    }
    
	private static void showContext() throws Throwable {
		String[] beanNames = ctx.getBeanDefinitionNames();

		for (String beanName : beanNames) {
			System.out.println("beanName = " + beanName);
		}
	}
    
    public static void jpa() {
    	JpaTorderService jpaService = ctx.getBean(JpaTorderService.class);
    	
    	
    	Product product1 = new Product();
    	product1.setName("product name 1");
    	product1.setProductCode(1L);
    	
    	Product product2 = new Product();
    	product2.setName("product name 2");
    	product2.setProductCode(2L);
    	
    	OrderItem orderItem1 = new OrderItem();
    	orderItem1.setPrice(100L);
    	orderItem1.setOrderId(1L);
    	orderItem1.setProduct(product1);
    	
    	OrderItem orderItem2 = new OrderItem();
    	orderItem2.setPrice(100L);
    	orderItem2.setOrderId(2L);
    	orderItem2.setProduct(product2);
    	
    	Torder order = new Torder();
    	order.setOrderTime(new Date(0));
    	order.setOrderStatus("active");
   
    	HashSet<OrderItem> orderitems= new HashSet();
    	orderitems.add(orderItem1);
    	orderitems.add(orderItem2);
    	
    	order.setOrderItem(orderitems);
    	System.out.println("JPA insert");
    	System.out.println(jpaService.addOrder(order).toString());
    	System.out.println(jpaService.all().toString());
    	
    	
    	System.out.println("JPA getById");
    	System.out.println(jpaService.getById(1L));
    	
    	System.out.println("JPA update");
    	jpaService.update();
    	System.out.println(jpaService.all().toString());
    	
    	System.out.println("JPA remove");
    	jpaService.delById(1L);
    	System.out.println(jpaService.all().toString());
    	
    	
    	System.out.println("JAP test end");
    	
    	
    }
    
    
    private static void repository() throws Throwable {
		System.out.println("JPA Repository Service ...");

		JpaTordertRepositoryService jpaTordertRepositoryService = ctx.getBean(JpaTordertRepositoryService.class);
		System.out.println("jpaClientRepositoryService=" + jpaTordertRepositoryService);
		
		System.out.println("JPA repository save");
		Torder torder = new Torder();
		torder.setOrderTime(new Date(0));
		torder.setOrderStatus("active");
		jpaTordertRepositoryService.save(torder);
		System.out.println(jpaTordertRepositoryService.findAll().toString());
		
		
		System.out.println("JPA repository update");
		
		Torder torder2 = jpaTordertRepositoryService.findOne(1L);
		//Torder torder2 = new Torder();
		torder2.setOrderStatus("xxxxxxxx");
		//torder2.setId(2L);
		jpaTordertRepositoryService.save(torder2);
		System.out.println(jpaTordertRepositoryService.findAll().toString());
		
		
		System.out.println("JPA repository delete");
		
		jpaTordertRepositoryService.delete(1L);

	}
    
    
	private static void mybatis() throws Throwable {
		System.out.println("Mybatis...");
		MybatisTorderService mybatisTorderService = ctx.getBean(MybatisTorderService.class);

		
	   	Product product1 = new Product();
	   	product1.setId(1L);
    	product1.setName("product name 1");
    	product1.setProductCode(1L);
    	
    	Product product2 = new Product();
    	product2.setId(2L);
    	product2.setName("product name 2");
    	product2.setProductCode(2L);
    	
    	OrderItem orderItem1 = new OrderItem();
    	orderItem1.setPrice(100L);
    	orderItem1.setOrderId(1L);
    	orderItem1.setProductId(1L);
    	orderItem1.setProduct(product1);
    	
    	OrderItem orderItem2 = new OrderItem();
    	orderItem2.setPrice(100L);
    	orderItem2.setOrderId(2L);
    	orderItem2.setProductId(2L);
    	orderItem2.setProduct(product2);
    	
    	Torder order = new Torder();
    	order.setOrderTime(new Date(0));
    	order.setOrderStatus("active");
   
    	HashSet<OrderItem> orderitems= new HashSet();
    	orderitems.add(orderItem1);
    	orderitems.add(orderItem2);
    	
    	order.setOrderItem(orderitems);
    	
		Integer result = mybatisTorderService.addTorder(order);
		System.out.println("torder=" + order.toString());

		order = mybatisTorderService.getById(1);
		System.out.println("torder=" + order.toString());
		
		order.setOrderStatus("xxxxxx");
		
		mybatisTorderService.updateById(order);
		
		order = mybatisTorderService.getById(1);
		System.out.println("torder=" + order.toString());
		
		mybatisTorderService.delById(1);
		order = mybatisTorderService.getById(1);
		
		if (order == null) {
			System.out.println("all data removed");
		}
		
//		
//		client = mybatisService.getById(2);
//		System.out.println("client[2]="+client);
	}
	
	private static void sql() throws Throwable {
		/*
		 * Prepare Data
		 */
JpaTorderService jpaService = ctx.getBean(JpaTorderService.class);
    	
    	
    	Product product1 = new Product();
    	product1.setName("product name 1");
    	product1.setProductCode(1L);
    	
    	Product product2 = new Product();
    	product2.setName("product name 2");
    	product2.setProductCode(2L);
    	
    	OrderItem orderItem1 = new OrderItem();
    	orderItem1.setPrice(100L);
    	orderItem1.setOrderId(1L);
    	orderItem1.setProduct(product1);
    	
    	OrderItem orderItem2 = new OrderItem();
    	orderItem2.setPrice(100L);
    	orderItem2.setOrderId(2L);
    	orderItem2.setProduct(product2);
    	
    	Torder order = new Torder();
    	order.setOrderTime(new Date(0));
    	order.setOrderStatus("active");
   
    	HashSet<OrderItem> orderitems= new HashSet();
    	orderitems.add(orderItem1);
    	orderitems.add(orderItem2);
    	
    	order.setOrderItem(orderitems);
    	System.out.println("JPA insert");
    	System.out.println(jpaService.addOrder(order).toString());

		/*
		 * SQL Query
		 */
    	MybatisSqlService mybatisSqlService = ctx.getBean(MybatisSqlService.class);
		List list = mybatisSqlService.query();

		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(list);
		System.out.println("json=" + json);
	}
    
}
