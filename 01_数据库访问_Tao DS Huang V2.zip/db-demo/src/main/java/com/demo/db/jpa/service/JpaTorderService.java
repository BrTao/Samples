package com.demo.db.jpa.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.demo.db.entity.Torder;

@Service
@Transactional
public class JpaTorderService {
	@PersistenceContext
	EntityManager entityManager;
	
	public Torder addOrder(Torder torder) {
		System.out.println(entityManager.toString());
		entityManager.persist(torder);
		return torder;
	}
	
	public Torder getById(Long orderId) {
		return entityManager.find(Torder.class, orderId);
	}
	
	public void delById(Long id) {
		
		entityManager.remove(getById(id));
	}
	
	public void update() {
		
		Torder torder = getById(1L);
		torder.setOrderStatus("xxxxxxxxxx");
	}
	
	public List<Torder> all() {
		Query query = entityManager.createQuery("from Torder");
		return query.getResultList();
	}
}
