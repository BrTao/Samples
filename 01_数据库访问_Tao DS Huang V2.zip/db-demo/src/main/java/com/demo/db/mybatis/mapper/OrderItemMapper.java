package com.demo.db.mybatis.mapper;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.demo.db.entity.OrderItem;


public interface OrderItemMapper {
	@Options(useGeneratedKeys = true, keyProperty = "id") //回写自增的主键ID
	@Insert("insert into orderItem (order_id, price, product_id) values(#{orderId}, #{price}, #{productId})")
	public Integer addOrderItem(OrderItem orderItem);
	
	//@Select("select * from orderItem where id=#{id}")
	public OrderItem getById(Integer id);
	
	List<OrderItem> listByOrderId(@Param("orderId") Serializable orderId);
}
