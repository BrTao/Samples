package com.demo.db.mybatis.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import com.demo.db.entity.Torder;


public interface TorderMapper {
	@Options(useGeneratedKeys = true, keyProperty = "id") //回写自增的主键ID
	@Insert("insert into torder (order_status, order_time) values(#{orderStatus}, #{orderTime})")
	public Integer addTorder(Torder torder);
	
	//@Select("select * from torder where id=#{id}")
	public Torder getById(Integer id);
	public Integer updateById(Torder torder);
	public Integer delById(Integer id);
}
