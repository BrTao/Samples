package com.demo.db.mybatis.mapper;

import java.io.Serializable;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.demo.db.entity.Product;
import com.demo.db.entity.Torder;


public interface ProductMapper {
	@Options(useGeneratedKeys = true, keyProperty = "id") //回写自增的主键ID
	@Insert("insert into product (product_code, name) values(#{productCode}, #{name})")
	public Integer addProduct(Product product);
	
	//@Select("select * from product where id=#{id}")
	public Product getById(@Param("id") Serializable id);
}
