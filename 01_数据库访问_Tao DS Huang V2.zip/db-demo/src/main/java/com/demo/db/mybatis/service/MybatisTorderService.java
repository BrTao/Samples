package com.demo.db.mybatis.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.demo.db.entity.OrderItem;
import com.demo.db.entity.Product;
import com.demo.db.entity.Torder;
import com.demo.db.mybatis.mapper.OrderItemMapper;
import com.demo.db.mybatis.mapper.ProductMapper;
import com.demo.db.mybatis.mapper.TorderMapper;


@Service
public class MybatisTorderService {
	@Resource
	TorderMapper tordermapper;
	
	@Resource
	OrderItemMapper orderItemMapper;
	
	@Resource
	ProductMapper productMapper;
	
	
	public Integer addTorder(Torder torder) {
		Integer result = tordermapper.addTorder(torder);
		for(OrderItem orderItem : torder.getOrderItem()) {
			orderItem.setOrderId(torder.getId());
			result = orderItemMapper.addOrderItem(orderItem);
			Product product = orderItem.getProduct();
			result = productMapper.addProduct(product);
		}
		return result; 
	}
	
	public Torder getById(Integer id) {
		return tordermapper.getById(id);
	}
	
	public void updateById(Torder torder) {
		tordermapper.updateById(torder);
	}
	
	public void delById(Integer id) {
		tordermapper.delById(id);
		
	}
}
