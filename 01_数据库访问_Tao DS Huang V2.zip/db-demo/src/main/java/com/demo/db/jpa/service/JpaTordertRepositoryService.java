package com.demo.db.jpa.service;

import org.springframework.data.repository.CrudRepository;

import com.demo.db.entity.Torder;


public interface JpaTordertRepositoryService extends CrudRepository<Torder, Long>  {

}
