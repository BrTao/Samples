package com.demo.spring.upload.controler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class Preview {
	
	 @Autowired  
	 private HttpSession session;  
	 
	 @Autowired  
	 private HttpServletResponse response; 
	
	 @GetMapping("/basic/preview")
	 @ResponseBody
	 public void showImg() {
		 
		 String path=(String) session.getAttribute("path");
				 
	        try {
	            InputStream is = new FileInputStream(new File(path));
	            OutputStream os = response.getOutputStream();
	            byte[] b = new byte[2048];
	            int length;
	            while ((length = is.read(b)) > 0) {
	                os.write(b, 0, length);
	            }
	            response.flushBuffer();
	            os.close();
	            is.close();
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
		 
//		 return export(new File(path));
	 }
	 
	 public ResponseEntity<FileSystemResource> export(File file) {
		    if (file == null) {
		        return null;
		    }
		    HttpHeaders headers = new HttpHeaders();
		    headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
//		    headers.add("Content-Disposition", "attachment; filename=" + System.currentTimeMillis() + ".xls");
		    headers.add("Pragma", "no-cache");
		    headers.add("Expires", "0");
		    headers.add("Last-Modified", new Date().toString());
		    headers.add("ETag", String.valueOf(System.currentTimeMillis()));

		    return ResponseEntity
		            .ok()
		            .headers(headers)
		            .contentLength(file.length())
//		            .contentType(MediaType.parseMediaType("application/octet-stream"))
		            .contentType(MediaType.parseMediaType("image/jpeg"))
		            .body(new FileSystemResource(file));
		}

}
