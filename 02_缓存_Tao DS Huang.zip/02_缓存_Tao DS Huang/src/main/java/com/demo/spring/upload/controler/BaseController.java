package com.demo.spring.upload.controler;

public class BaseController {
    
    //Save the uploaded file to this folder
    public static String UPLOADED_FOLDER = "C://upload//";
}
