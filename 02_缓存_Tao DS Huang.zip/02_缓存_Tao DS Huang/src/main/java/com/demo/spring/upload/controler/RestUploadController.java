package com.demo.spring.upload.controler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.demo.spring.model.UploadModel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@RestController
public class RestUploadController extends BaseController {
    
    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);
    
	 @Autowired  
	 private HttpSession session;  
	 
	 @Autowired  
	 private HttpServletResponse response; 
    
    // 3.1.1 Single file upload
    @PostMapping("/api/upload")
    // If not @RestController, uncomment this
    //@ResponseBody
    public ResponseEntity<?> uploadFile(
        @RequestParam("file") MultipartFile uploadfile) {
        
        logger.debug("Single file upload!");
        
        if (uploadfile.isEmpty()) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        
        try {
            
            saveUploadedFiles(Arrays.asList(uploadfile));
            
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        return new ResponseEntity("Successfully uploaded - " +
                                      uploadfile.getOriginalFilename(), new HttpHeaders(), HttpStatus.OK);
        
    }
    
    // 3.1.2 Multiple file upload
    @PostMapping("/api/upload/multi")
    public ResponseEntity<?> uploadFileMulti(
        @RequestParam("extraField") String extraField,
        @RequestParam("files") MultipartFile[] uploadfiles) {
        
        logger.debug("Multiple file upload!");
        
        // Get file name
        String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                                      .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));
        
        if (StringUtils.isEmpty(uploadedFileName)) {
            return new ResponseEntity("please select a file!", HttpStatus.OK);
        }
        
        try {
            
            saveUploadedFiles(Arrays.asList(uploadfiles));
            
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        return new ResponseEntity("Successfully uploaded - "
                                      + uploadedFileName, HttpStatus.OK);
        
    }
    
    // 3.1.3 maps html form to a Model
    @PostMapping("/api/upload/multi/model")
    public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadModel model) {
        
        logger.debug("Multiple file upload! With UploadModel");
        
        try {
            
            saveUploadedFiles(Arrays.asList(model.getFiles()));
            
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        return new ResponseEntity("Successfully uploaded - " + model.toString(), HttpStatus.OK);
        
    }
    
    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {
        int i = 1;
        for (MultipartFile file : files) {
            
            if (file.isEmpty()) {
                continue; //next pls
            }
            
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);
            session.setAttribute("path" + i, path.toString());
            
            i++;
        }
        
    }
    
    
     @GetMapping("/rest/preview")
	 @ResponseBody
	 public void showImg(@RequestParam("seq") String seq) {
    	 String path = null;
    	 if (seq.equals("1")) {
    		 path = (String) session.getAttribute("path1");

    	 }else {
    		 path = (String) session.getAttribute("path2");

    	 }

				 
	        try {
	            InputStream is = new FileInputStream(new File(path));
	            OutputStream os = response.getOutputStream();
	            byte[] b = new byte[2048];
	            int length;
	            while ((length = is.read(b)) > 0) {
	                os.write(b, 0, length);
	            }
	            response.flushBuffer();
	            os.close();
	            is.close();
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
		 
//		 return export(new File(path));
	 }
}
