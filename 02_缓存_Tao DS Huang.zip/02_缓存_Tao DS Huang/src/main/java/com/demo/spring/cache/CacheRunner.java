package com.demo.spring.cache;

import com.demo.spring.jpa.service.JpaTorderService;
import com.demo.spring.model.OrderItem;
import com.demo.spring.model.Product;
import com.demo.spring.model.Torder;

import lombok.extern.slf4j.Slf4j;

import java.sql.Date;
import java.util.HashSet;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CacheRunner implements CommandLineRunner, ApplicationContextAware {
    private final JpaTorderService jpaTorderService;
    
    public ApplicationContext ctx;
    
    public CacheRunner(JpaTorderService jpaTorderService) {
        this.jpaTorderService = jpaTorderService;
    }
    
    @Override
    public void run(String... args) throws Exception {
//        jpa(args.toString());
//        log.info(".... start cache testing .....");
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());
//        log.info(jpaTorderService.getById(1L).toString());


    }
    
    
    public void jpa(String args) {
    	System.out.println("test1");
//    	ctx = new FileSystemXmlApplicationContext("application.properties");
//    	System.out.println("test2");
    	JpaTorderService jpaService = ctx.getBean(JpaTorderService.class);
    	System.out.println("test3");
    	
    	Product product1 = new Product();
    	product1.setName("product name 1");
    	product1.setProductCode(1L);
    	
    	Product product2 = new Product();
    	product2.setName("product name 2");
    	product2.setProductCode(2L);
    	
    	OrderItem orderItem1 = new OrderItem();
    	orderItem1.setPrice(100L);
    	orderItem1.setOrderId(1L);
    	orderItem1.setProduct(product1);
    	
    	OrderItem orderItem2 = new OrderItem();
    	orderItem2.setPrice(100L);
    	orderItem2.setOrderId(2L);
    	orderItem2.setProduct(product2);
    	
    	Torder order = new Torder();
    	order.setOrderTime(new Date(0));
    	order.setOrderStatus("active");
   
    	HashSet<OrderItem> orderitems= new HashSet();
    	orderitems.add(orderItem1);
    	orderitems.add(orderItem2);
    	
    	order.setOrderItem(orderitems);
    	System.out.println("JPA insert");
    	System.out.println(jpaService.addOrder(order).toString());
    	System.out.println(jpaService.all().toString());
    	
   
    	
    }
    
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.ctx = applicationContext;
    }
}
