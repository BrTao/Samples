package com.demo.spring.upload.controler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RestIndexController {
    
    @GetMapping("/rest")
    public String index() {
        return "/rest/index";
    }
}
