package com.demo.spring.jpa.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.demo.spring.model.Torder;


@Service
@Transactional
@Component
public class JpaTorderService {
	@PersistenceContext
	EntityManager entityManager;
	
	public Torder addOrder(Torder torder) {
		System.out.println(entityManager.toString());
		entityManager.persist(torder);
		return torder;
	}
	
	@Cacheable("torder")
	public Torder getById(Long orderId) {
		simulateSlowService();
		return entityManager.find(Torder.class, orderId);
	}
	
	public void delById(Long id) {
		
		entityManager.remove(getById(id));
	}
	
	public void update() {
		
		Torder torder = getById(1L);
		torder.setOrderStatus("xxxxxxxxxx");
	}
	
	public List<Torder> all() {
		Query query = entityManager.createQuery("from Torder");
		return query.getResultList();
	}
	
    private void simulateSlowService() {
        try {
            long time = 3000L;
            Thread.sleep(time);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }
}
