create table if not exists torder (
  id            int not null primary key auto_increment,
  order_status  varchar(10),
  order_time    date
);



create table if not exists orderitem (
  id            int not null primary key auto_increment,
  order_id      int,
  price         int,
  product_id    int
);



create table if not exists product (
  id              int not null primary key auto_increment,
  product_code    int,
  name            varchar(50)
);

commit;
